#include <cstdlib>
#include <iostream>
#include <random>
#include <string>
#include <cctype>
using namespace std;

// Create a random number generator
random_device rd;
mt19937 gen(rd());
// Create a function to generate a random number between 1 and 6
// int rollDice();

uniform_int_distribution<int> distribution(1, 20);
// create a function named randomNumber to generate a random number between 1
// and 20
int main() {
  // Create a collection (list, vector, array) of 20 word roots
  string wordRoots[20] = {"ambi", "aud",   "circum",   "contra", "dict",
                          "fort", "fract", "mit",      "multi",  "mod",
                          "par",  "spect", "anthropo", "bio",    "chron",
                          "dyna", "gram",  "hetero",   "hydro",  "meter"};

  // create a list of 20 prefixes
  string prefixes[20] = {"anti",  "auto", "de", "dis",   "en",  "ex",   "extra",
                         "hyper", "il",   "in", "inter", "mid", "mis",  "non",
                         "over",  "pre",  "re", "semi",  "sub", "super"};

  // creat an array of 20 strings that contain prefixes
  string suffixes[20] = {"able", "al",   "ed",  "en",  "er",  "est",  "ful",
                         "ic",   "ing",  "ion", "ish", "ive", "less", "ly",
                         "ment", "ness", "ous", "s",   "y","ee"};

  // creat a random index for the prefixes array
  int prefixIndex = distribution(gen) % 20;
  // generate random indices for word roots and suffixes
  int wordRootIndex = distribution(gen) % 20;
  int suffixIndex = distribution(gen) % 20;
  // print a word using a random index from prefixes, suffixes, and wordRoots
string prefix=prefixes[prefixIndex];
  //capitlalize the first letter of the word
  prefix[0] = toupper(prefix[0]);

  cout << prefix << wordRoots[wordRootIndex]
       << suffixes[suffixIndex]<< " means, ";
  // create an array of defintions for "anti", "auto", "de", "dis", "en", "ex",
  // "extra", "hyper", "il", "in", "inter", "mid", "mis", "non", "over", "pre",
  // "re", "semi", "sub", "super"
  string defprefixes[20]{"against",    "self",   "from", "apart of/from",
                     "in",     "without or from", "beyond",         "above",
                     "not or without",        "not or against",          "between",         "middle",
                     "incorrectly", "not",         "too much",          "before",
                     "again with",         "partially or partial",        "underneath",           "over"};
  // create an array of defintions for "able", "al", "ed", "en", "er", "est",
  // "ful", "ic", "ing", "ion", "ish", "ive", "less", "ly", "ment", "ness",
  // "ous", "s", "y","ee"
  string defsuffixes[20]{"creating",
                     "pertaining to or based on",
                     "pertaining to the past",
                     "made from or becoming",
                     "perfecting",
                     "current conduction",
                     "completion",
                     "resembling",
                     "acting",
                     "going",
                     "state of being",
                     "describing",
                     "lessening",
                     "currently undergoing",
                     "resulting from",
                     "becoming",
                     "full of",
                     "multiplying",
                     "characterized by or inclined to","the person recipient or condition of a person"};
//create an array of defintions for "ambi", "aud", "circum", "contra", "dict", "fort", "fract", "mit",      "multi",  "mod","par",  "spect", "anthropo", "bio",    "chron","dyna", "gram",  "hetero",   "hydro",  "meter"

string defwordRoots[20]{"both", "sound", "surrounding", "against", "language", "strength", "fraction", "inside", "many", "manner","equality", "observation", "human", "life","time","power","writting","difference","water","measurement" };
  cout << defsuffixes[suffixIndex] << " "<<defprefixes[prefixIndex]<<" the "
     << defwordRoots[wordRootIndex]<< ".";
  
  return 0;
}
